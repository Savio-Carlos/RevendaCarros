export class Peca {
    id!: number;
    nome!: string;
    marca!: string;
    estoque!: number;
    preco!: number;
    fotoUrl!: string;
}
