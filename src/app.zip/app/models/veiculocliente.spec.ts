import { Veiculocliente } from './veiculocliente';

describe('Veiculocliente', () => {
  it('should create an instance', () => {
    expect(new Veiculocliente()).toBeTruthy();
  });
});
