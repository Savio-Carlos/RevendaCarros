import { Peca } from "./peca";

export interface Itemcarrinho {
    peca: Peca;
    quantidade: number;
}
