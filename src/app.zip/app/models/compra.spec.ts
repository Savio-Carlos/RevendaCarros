import { Compra } from './compra';

describe('Compra', () => {
  it('should create an instance', () => {
    expect(new Compra()).toBeTruthy();
  });
});
