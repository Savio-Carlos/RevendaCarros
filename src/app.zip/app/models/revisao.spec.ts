import { Revisao } from './revisao';

describe('Revisao', () => {
  it('should create an instance', () => {
    expect(new Revisao()).toBeTruthy();
  });
});
