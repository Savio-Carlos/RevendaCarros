export class Carro {
    id!: number;
    modelo!: string;
    marca!: string;
    ano!: number;
    preco!: number;
    combustivel!: string;
    cambio!: string;
    kms!: number;
    fotoUrl!: string;
    placa!: string;
}
