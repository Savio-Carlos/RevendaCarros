import { Component } from '@angular/core';

@Component({
  selector: 'app-gerenteveiculos',
  imports: [],
  templateUrl: './gerenteveiculos.component.html',
  styleUrl: './gerenteveiculos.component.scss'
})
export class GerenteveiculosComponent {

}
